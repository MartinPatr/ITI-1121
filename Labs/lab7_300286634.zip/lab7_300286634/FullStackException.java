public class FullStackException extends RuntimeException {
    public FullStackException(){
        super();    
    }
}
